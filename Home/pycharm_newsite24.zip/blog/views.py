# from flask import Blueprint, render_template
#
# views = Blueprint("views", __name__)
#
#
# @views.route("/")
# @views.route("/home")
# def home():
#     return render_template("home.html")


# views.py

from flask import Blueprint, render_template

views = Blueprint("views", __name__)

@views.route("/")
def home():
    return render_template("index.html")

@views.route("/about")
def about():
    return render_template("about.html")

@views.route("/categories-list")
def categories_list():
    return render_template("categories_list.html")

@views.route("/post-list")
def post_list():
    return render_template("post_list.html")

@views.route('posts/<int:id>')
def post_detail():
    return render_template("post_detail.html")

@views.route("/contact")
def contact():
    return render_template("contact.html")


# from flask import Blueprint, render_template, send_from_directory
#
# views = Blueprint('views', __name__)
#
# @views.route("/")
# def index():
#     return send_from_directory('THEME', 'index.html')
#
# @views.route('/<path:name>')
# def start(name):
#     return send_from_directory('THEME', name)


















# from flask import Blueprint, render_template
#
# views = Blueprint("views", __name__)
#
# @views.route("/")
# def blog_home():
#     return render_template("index.html")
#
# @views.route("/about_me")
# def about_me():
#     return render_template("about.html")