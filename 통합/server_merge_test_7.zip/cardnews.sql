CREATE DATABASE cardnews;
USE cardnews;

CREATE TABLE images (
id INT AUTO_INCREMENT PRIMARY KEY,
title VARCHAR(255) NOT NULL,
instagram_link VARCHAR(255) NOT NULL,
image_path VARCHAR(255) NOT NULL,
view_count INT DEFAULT 0,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    instagram_link VARCHAR(255) NOT NULL,
    video_path VARCHAR(255) NOT NULL,
    view_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO images (title, instagram_link, image_path, view_count) VALUES
('Image 1', 'https://www.instagram.com/p/image1/', 'static/card/image1.jpg', 5),
('Image 2', 'https://www.instagram.com/p/image2/', 'static/card/image2.jpg', 4),
('Image 3', 'https://www.instagram.com/p/image3/', 'static/card/image3.jpg', 3),
('Image 4', 'https://www.instagram.com/p/image4/', 'static/card/image4.jpg', 2),
('Image 5', 'https://www.instagram.com/p/image2/', 'static/card/image5.jpg', 1),
('Image 6', 'https://www.instagram.com/p/image3/', 'static/card/image6.jpg', 0);

INSERT INTO videos (title, instagram_link, video_path, view_count) VALUES
('Video 1', 'https://www.instagram.com/p/video1/', 'static/card/video1.mp4', 5),
('Video 2', 'https://www.instagram.com/p/video2/', 'static/card/video2.mp4', 4),
('Video 3', 'https://www.instagram.com/p/video3/', 'static/card/video3.mp4', 3),
('Video 4', 'https://www.instagram.com/p/video4/', 'static/card/video4.mp4', 2),
('Video 5', 'https://www.instagram.com/p/video5/', 'static/card/video5.mp4', 1),
('Video 6', 'https://www.instagram.com/p/video6/', 'static/card/video6.mp4', 0);

SELECT * FROM images;
SELECT * fROM videos;

USE cardnews;
SHOW TABLES;

