CREATE DATABASE timetb;
USE timetb;

CREATE TABLE timetable (
id INT AUTO_INCREMENT PRIMARY KEY,
monday VARCHAR(255),
tuesday VARCHAR(255),
wednesday VARCHAR(255),
thursday VARCHAR(255),
friday VARCHAR(255)
);

desc timetable;

SELECT * FROM timetable;

INSERT INTO timetable (monday, tuesday, wednesday, thursday, friday) VALUES ('test1', 'test2', 'default_value', 'default_value', 'default_value');

CREATE TABLE notes_table (
    id INT AUTO_INCREMENT PRIMARY KEY,
    notes TEXT
);

INSERT INTO notes_table (notes) VALUES ('');