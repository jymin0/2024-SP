##제일 최신
from blog import create_app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)



# from blog import create_app
#
# app = create_app()
#
# if __name__ == '__main__':
#     app.run(debug=True)


# from flask import Flask
#
# app = Flask(__name__)
#
#
# @app.route('/')
# def hello_world():  # put application's code here
#     return 'Hello World!'
#
#
# if __name__ == '__main__':
#     app.run()
