# from flask import Flask, render_template, send_from_directory

# app = Flask(__name__)

# @app.route("/") #도메인
# def index():
#     return send_from_directory('THEME', 'index.html')

# @app.route('/<path:name>') #도메인/css/b.scc
# def start(name):
#     return send_from_directory('THEME', name)

# # from . import create_app

# # app = create_app()

# # if __name__ == "__main__":
# #     app.run(debug=True)


from flask import Flask, render_template, send_from_directory, request, redirect, url_for, flash
from flask_mysqldb import MySQL
from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = '0000'
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'myuser'
app.config['MYSQL_PASSWORD'] = 'mypassword'
app.config['MYSQL_DB'] = 'mydb'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql = MySQL(app)
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

class User(UserMixin):
    def __init__(self, user_data):
        self.id = user_data['id']
        self.email = user_data['email']
        self.username = user_data['username']
        self.password = user_data['password']

    @staticmethod
    def get(user_id):
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        user = cur.fetchone()
        if user:
            return User(user)
        return None

@login_manager.user_loader
def load_user(user_id):
    return User.get(user_id)

@app.route("/") # 도메인
def index():
    return send_from_directory('THEME', 'index.html')

@app.route('/<path:name>') # 도메인/css/b.css
def serve_static(name):
    return send_from_directory('THEME', name)

@app.route("/login", methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cur.fetchone()
        if user and check_password_hash(user['password'], password):
            user_obj = User(user)
            login_user(user_obj, remember=True)
            flash("Logged in successfully!", category='success')
            return redirect(url_for('index'))
        else:
            flash('Email or password is incorrect', category='error')
    return render_template("login.html")

@app.route("/sign-up", methods=['GET', 'POST'])
def sign_up():
    if request.method == 'POST':
        email = request.form.get('email')
        username = request.form.get('username')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email = %s", (email,))
        email_exists = cur.fetchone()

        cur.execute("SELECT * FROM users WHERE username = %s", (username,))
        username_exists = cur.fetchone()

        if email_exists:
            flash('Email is already in use.', category='error')
        elif username_exists:
            flash('Username is already in use.', category='error')
        elif password1 != password2:
            flash('Passwords don\'t match!', category='error')
        elif len(username) < 2:
            flash('Username is too short.', category='error')
        elif len(password1) < 6:
            flash('Password is too short.', category='error')
        elif len(email) < 4:
            flash("Email is invalid.", category='error')
        else:
            hashed_password = generate_password_hash(password1, method='sha256')
            cur.execute("INSERT INTO users (email, username, password) VALUES (%s, %s, %s)",
                        (email, username, hashed_password))
            mysql.connection.commit()
            cur.execute("SELECT * FROM users WHERE email = %s", (email,))
            new_user = cur.fetchone()
            user_obj = User(new_user)
            login_user(user_obj, remember=True)
            flash('User created!')
            return redirect(url_for('index'))

    return render_template("signup.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
