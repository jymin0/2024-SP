from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import pymysql
from flask_mysqldb import MySQL

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # 세션을 사용하려면 필요합니다.

# 로그인 정보 저장하는 데이터베이스 설정
login_db = pymysql.connect(
    host="localhost",
    user="root",
    password='root',  # 로그인 데이터베이스 비밀번호
    database="member"  # 로그인 데이터베이스 이름
)

# 카드뉴스 저장하는 데이터베이스 설정
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'  # 카드뉴스 데이터베이스 비밀번호
app.config['MYSQL_DB'] = 'cardnews'  # 카드뉴스 데이터베이스 이름

mysql = MySQL(app)

# 게시판 데이터베이스 설정
board_db = pymysql.connect(
    host="localhost",
    user="root",
    password='root',  # 게시판 데이터베이스 비밀번호
    database="board_db",  # 게시판 데이터베이스 이름
    charset='utf8',
    cursorclass=pymysql.cursors.DictCursor
)

# 시간표 데이터베이스 설정
timetable_db = pymysql.connect(
    host='localhost',
    user='root',
    password='root',  # 시간표 데이터베이스 비밀번호
    database='timetb',
    cursorclass=pymysql.cursors.DictCursor
)

@app.before_request
def before_request():
    if 'logged_in' not in session:
        session['logged_in'] = False

@app.route('/')
def home():
    return redirect(url_for('index'))
6
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cursor = login_db.cursor(pymysql.cursors.DictCursor)
        query = "SELECT * FROM members WHERE email = %s AND password = %s"
        cursor.execute(query, (email, password))
        result = cursor.fetchone()
        cursor.close()

        if result:
            session['email'] = email 
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            return redirect(url_for('login'))

    return render_template('login.html', logged_in=session.get('logged_in', False))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cursor = login_db.cursor()
        query = "INSERT INTO members (email, password) VALUES (%s, %s)"
        cursor.execute(query, (email, password))
        login_db.commit()
        cursor.close()

        return redirect(url_for('login'))

    return render_template('signup.html', logged_in=session.get('logged_in', False))

@app.route('/index')
def index():
    return render_template('index.html', logged_in=session.get('logged_in', False))

@app.route('/timetable')
def timetable():
    return render_template('timetable.html', logged_in=session.get('logged_in', False))

@app.route('/cardnews', methods=['GET', 'POST'])  # GET 및 POST 메서드 허용
def cardnews():
    sort_by = request.args.get('sort_by', 'created_at')
    sort_order = request.args.get('sort_order', 'desc')

    if request.method == 'POST':  # POST 메서드일 경우
        # 검색어를 받아와서 검색 라우트로 리다이렉트
        search_input = request.form.get('searchInput', '').strip().lower()
        return redirect(url_for('search', search_input=search_input))

    mydb = MySQL()  # MySQL 객체 생성
    cursor = mydb.connection.cursor()  # MySQL 객체를 통해 커서 생성
    cursor.execute(f"SELECT * FROM images ORDER BY {sort_by} {sort_order}")
    image_data = cursor.fetchall()
    cursor.execute(f"SELECT * FROM videos ORDER BY {sort_by} {sort_order}")
    video_data = cursor.fetchall()
    cursor.close()

    return render_template('cardnews.html', image_data=image_data, video_data=video_data, sort_by=sort_by, sort_order=sort_order, logged_in=session.get('logged_in', False))

@app.route('/search', methods=['POST'])  # POST 메서드로 변경
def search():
    search_keyword = request.form.get('search_input', '').strip().lower()  # 검색어를 제대로 받아오도록 수정
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM images WHERE title LIKE %s", ('%' + search_keyword + '%',))
    filtered_image_data = cursor.fetchall()
    cursor.execute("SELECT * FROM videos WHERE title LIKE %s", ('%' + search_keyword + '%',))
    filtered_video_data = cursor.fetchall()
    cursor.close()

    return render_template('cardnews.html', image_data=filtered_image_data, video_data=filtered_video_data, logged_in=session.get('logged_in', False))


@app.route('/increment_view/<int:item_id>')
def increment_view(item_id):
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM images")
    image_data = cursor.fetchall()
    if item_id <= len(image_data):
        cursor.execute("UPDATE images SET view_count = view_count + 1 WHERE id = %s", (item_id,))
    else:
        cursor.execute("SELECT * FROM videos")
        video_data = cursor.fetchall()
        video_id = item_id - len(image_data)
        cursor.execute("UPDATE videos SET view_count = view_count + 1 WHERE id = %s", (video_id,))
    mysql.connection.commit()
    cursor.close()

    if item_id <= len(image_data):
        return redirect(image_data[item_id - 1][2])
    else:
        return redirect(video_data[video_id - 1][2])

@app.route('/board')
def board():
    cursor = board_db.cursor()
    cursor.execute("SELECT * FROM posts")
    posts = cursor.fetchall()
    cursor.close()
    return render_template('board.html', posts=posts, logged_in=session.get('logged_in', False))

@app.route('/read/<int:id>/', methods=['GET', 'POST'])
def read(id):
    cursor = board_db.cursor()

    # 게시글 내용 가져오기
    cursor.execute("SELECT * FROM posts WHERE id = %s", (id,))
    post = cursor.fetchone()

    # 댓글 내용 가져오기
    cursor.execute("SELECT * FROM comments WHERE post_id = %s ORDER BY created_at DESC", (id,))
    comments = cursor.fetchall()

    if request.method == 'POST':
        if not session.get('logged_in'):
            return redirect(url_for('login'))

        author = session['email']
        content = request.form['content']

        cursor.execute("INSERT INTO comments (post_id,  content) VALUES (%s, %s)", (id, content))
        board_db.commit()

        return redirect(url_for('read', id=id))

    cursor.close()
    return render_template('post.html', post=post, comments=comments, logged_in=session.get('logged_in', False))

@app.route('/create/', methods=['GET', 'POST'])
def create():
    if request.method == 'GET':
        cursor = board_db.cursor()
        cursor.execute("SELECT * FROM categories")
        categories = cursor.fetchall()

        return render_template('create_post.html', categories=categories, logged_in=session.get('logged_in', False))
    elif request.method == 'POST':
        category_id = request.form.get('category')
        title = request.form.get('title')
        content = request.form.get('content')


        if not title or not content or not category_id:
            return "모든 필드를 입력해주세요.", 400

        cursor = board_db.cursor()
        cursor.execute("INSERT INTO posts (title, content, category_id) VALUES (%s, %s, %s)",
                       (title, content, category_id))
        board_db.commit()

        return redirect('/board')

@app.route('/update/<int:id>/', methods=['GET', 'POST'])
def update(id):
    if request.method == 'GET':
        cursor = board_db.cursor()
        cursor.execute("SELECT * FROM posts WHERE id=%s", (id,))
        post = cursor.fetchone()

        cursor.execute("SELECT * FROM categories")
        categories = cursor.fetchall()

        return render_template('update_post.html', post=post, categories=categories, logged_in=session.get('logged_in', False))
    elif request.method == 'POST':
        title = request.form.get('title')
        content = request.form.get('content')
        category_id = request.form.get('category')

        cursor = board_db.cursor()
        cursor.execute("UPDATE posts SET title=%s, content=%s, category_id=%s WHERE id=%s",
                       (title, content, category_id, id))
        board_db.commit()

        return redirect(f'/read/{id}/')

@app.route('/delete/<int:id>/', methods=['POST'])
def delete(id):
    cursor = board_db.cursor()
    cursor.execute("DELETE FROM posts WHERE id=%s", (id,))
    board_db.commit()

    return redirect('/board')


# 댓글 삭제 기능
@app.route('/delete_comment/<int:comment_id>', methods=['POST'])
def delete_comment(comment_id):
    cursor = board_db.cursor()

    # 댓글이 있는 게시글 ID를 가져옵니다.
    cursor.execute("SELECT post_id FROM comments WHERE id = %s", (comment_id,))
    post_id = cursor.fetchone()['post_id']

    # 댓글 삭제
    cursor.execute("DELETE FROM comments WHERE id = %s", (comment_id,))
    board_db.commit()
    cursor.close()

    # 삭제 후 해당 게시글로 리디렉션
    return redirect(url_for('read', id=post_id))



@app.route('/mypage')
def mypage():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('mypage.html', logged_in=session.get('logged_in', False))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# 시간표 관련 API 엔드포인트 추가
@app.route('/api/timetable', methods=['GET'])
def get_timetable():
    with timetable_db.cursor() as cursor:
        cursor.execute("SELECT * FROM timetable")
        result = cursor.fetchall()
    return jsonify({'timetable': result})

@app.route('/api/update_timetable', methods=['POST'])
def update_timetable():
    try:
        data = request.json
        with timetable_db.cursor() as cursor:
            sql = "UPDATE timetable SET {} = %s WHERE id = %s".format(data['day'].lower())
            cursor.execute(sql, (data['value'], data['id']))
        timetable_db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/notes', methods=['GET'])
def get_notes():
    with timetable_db.cursor() as cursor:
        cursor.execute("SELECT notes FROM notes_table WHERE id = 1")
        result = cursor.fetchone()
    return jsonify({'notes': result['notes']})

@app.route('/api/save_notes', methods=['POST'])
def save_notes():
    try:
        data = request.json
        with timetable_db.cursor() as cursor:
            sql = "UPDATE notes_table SET notes = %s WHERE id = 1"
            cursor.execute(sql, (data['notes'],))
        timetable_db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)