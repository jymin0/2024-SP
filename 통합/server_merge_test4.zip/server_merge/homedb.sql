CREATE DATABASE member;
USE member;

CREATE TABLE members (
    id INT NOT NULL AUTO_INCREMENT,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    PRIMARY KEY (id)
);

INSERT INTO members (email, password) VALUES ('test@example.com', 'testpassword');
INSERT INTO members (email, password) VALUES ('test2@example.com', 'testpassword2');
