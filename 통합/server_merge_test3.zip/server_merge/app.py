from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import pymysql
from flask_mysqldb import MySQL

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # 세션을 사용하려면 필요합니다.

# 로그인 정보 저장하는 데이터베이스 설정
login_db = pymysql.connect(
    host="localhost",
    user="root",
    password="root",  # 로그인 데이터베이스 비밀번호
    database="member"  # 로그인 데이터베이스 이름
)

# 카드뉴스 저장하는 데이터베이스 설정
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'  # 카드뉴스 데이터베이스 비밀번호
app.config['MYSQL_DB'] = 'mydb'  # 카드뉴스 데이터베이스 이름

mysql = MySQL(app)

# 게시판 데이터베이스 설정
board_db = pymysql.connect(
    host="localhost",
    user="root",
    password="root",  # 게시판 데이터베이스 비밀번호
    database="board_db",  # 게시판 데이터베이스 이름
    charset='utf8',
    cursorclass=pymysql.cursors.DictCursor
)

# 시간표 데이터베이스 설정
timetable_db = pymysql.connect(
    host='localhost',
    user='root',
    password='root',  # 시간표 데이터베이스 비밀번호
    database='timetb',
    cursorclass=pymysql.cursors.DictCursor
)

@app.before_request
def before_request():
    if 'logged_in' not in session:
        session['logged_in'] = False

@app.route('/')
def home():
    return redirect(url_for('index'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cursor = login_db.cursor(pymysql.cursors.DictCursor)
        query = "SELECT * FROM members WHERE email = %s AND password = %s"
        cursor.execute(query, (email, password))
        result = cursor.fetchone()
        cursor.close()

        if result:
            session['email'] = email  # 로그인 성공 시 세션에 이메일 저장
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            return redirect(url_for('login'))

    return render_template('login.html', logged_in=session.get('logged_in', False))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cursor = login_db.cursor()
        query = "INSERT INTO members (email, password) VALUES (%s, %s)"
        cursor.execute(query, (email, password))
        login_db.commit()
        cursor.close()

        return redirect(url_for('login'))

    return render_template('signup.html', logged_in=session.get('logged_in', False))

@app.route('/index')
def index():
    return render_template('index.html', logged_in=session.get('logged_in', False))

@app.route('/timetable')
def timetable():
    return render_template('timetable.html', logged_in=session.get('logged_in', False))

@app.route('/cardnews')
def cardnews():
    sort_by = request.args.get('sort_by', 'created_at')
    sort_order = request.args.get('sort_order', 'desc')

    cursor = mysql.connection.cursor()
    cursor.execute(f"SELECT * FROM images ORDER BY {sort_by} {sort_order}")
    image_data = cursor.fetchall()
    cursor.execute(f"SELECT * FROM videos ORDER BY {sort_by} {sort_order}")
    video_data = cursor.fetchall()
    cursor.close()

    return render_template('cardnews.html', image_data=image_data, video_data=video_data, sort_by=sort_by, sort_order=sort_order, logged_in=session.get('logged_in', False))

@app.route('/search', methods=['POST'])
def search():
    search_keyword = request.form['searchInput'].lower()
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM images WHERE title LIKE %s", ('%' + search_keyword + '%',))
    filtered_image_data = cursor.fetchall()
    cursor.execute("SELECT * FROM videos WHERE title LIKE %s", ('%' + search_keyword + '%',))
    filtered_video_data = cursor.fetchall()
    cursor.close()

    return render_template('cardnews.html', image_data=filtered_image_data, video_data=filtered_video_data, logged_in=session.get('logged_in', False))

@app.route('/increment_view/<int:item_id>')
def increment_view(item_id):
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM images")
    image_data = cursor.fetchall()
    if item_id <= len(image_data):
        cursor.execute("UPDATE images SET view_count = view_count + 1 WHERE id = %s", (item_id,))
    else:
        cursor.execute("SELECT * FROM videos")
        video_data = cursor.fetchall()
        video_id = item_id - len(image_data)
        cursor.execute("UPDATE videos SET view_count = view_count + 1 WHERE id = %s", (video_id,))
    mysql.connection.commit()
    cursor.close()

    if item_id <= len(image_data):
        return redirect(image_data[item_id - 1][2])
    else:
        return redirect(video_data[video_id - 1][2])

@app.route('/board')
def board():
    category = request.args.get('category')
    cursor = board_db.cursor()

    if category:
        cursor.execute("SELECT * FROM posts WHERE category_id=%s", (category,))
    else:
        cursor.execute("SELECT * FROM posts")

    posts = cursor.fetchall()
    cursor.execute("SELECT * FROM categories")
    categories = cursor.fetchall()

    return render_template('board.html', categories=categories, posts=posts, logged_in=session.get('logged_in', False))

@app.route('/read/<int:id>/')
def read(id):
    cursor = board_db.cursor()
    cursor.execute("SELECT * FROM posts WHERE id=%s", (id,))
    post = cursor.fetchone()

    content = f'<h2>{post["title"]}</h2>{post["content"]}'
    cursor.execute("SELECT * FROM categories")
    categories = cursor.fetchall()

    return render_template('board.html', content=content, categories=categories, post=post, logged_in=session.get('logged_in', False))

@app.route('/create/', methods=['GET', 'POST'])
def create():
    if request.method == 'GET':
        cursor = board_db.cursor()
        cursor.execute("SELECT * FROM categories")
        categories = cursor.fetchall()

        return render_template('create_post.html', categories=categories, logged_in=session.get('logged_in', False))
    elif request.method == 'POST':
        title = request.form.get('title')
        content = request.form.get('content')
        category_id = request.form.get('category')

        if not title or not content or not category_id:
            return "모든 필드를 입력해주세요.", 400

        cursor = board_db.cursor()
        cursor.execute("INSERT INTO posts (title, content, category_id) VALUES (%s, %s, %s)",
                       (title, content, category_id))
        board_db.commit()

        return redirect('/board')

@app.route('/update/<int:id>/', methods=['GET', 'POST'])
def update(id):
    if request.method == 'GET':
        cursor = board_db.cursor()
        cursor.execute("SELECT * FROM posts WHERE id=%s", (id,))
        post = cursor.fetchone()

        cursor.execute("SELECT * FROM categories")
        categories = cursor.fetchall()

        return render_template('update_post.html', post=post, categories=categories, logged_in=session.get('logged_in', False))
    elif request.method == 'POST':
        title = request.form.get('title')
        content = request.form.get('content')
        category_id = request.form.get('category')

        cursor = board_db.cursor()
        cursor.execute("UPDATE posts SET title=%s, content=%s, category_id=%s WHERE id=%s",
                       (title, content, category_id, id))
        board_db.commit()

        return redirect(f'/read/{id}/')

@app.route('/delete/<int:id>/', methods=['POST'])
def delete(id):
    cursor = board_db.cursor()
    cursor.execute("DELETE FROM posts WHERE id=%s", (id,))
    board_db.commit()

    return redirect('/board')

@app.route('/mypage')
def mypage():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('mypage.html', logged_in=session.get('logged_in', False))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# 시간표 관련 API 엔드포인트 추가
@app.route('/api/timetable', methods=['GET'])
def get_timetable():
    with timetable_db.cursor() as cursor:
        cursor.execute("SELECT * FROM timetable")
        result = cursor.fetchall()
    return jsonify({'timetable': result})

@app.route('/api/update_timetable', methods=['POST'])
def update_timetable():
    try:
        data = request.json
        with timetable_db.cursor() as cursor:
            sql = "UPDATE timetable SET {} = %s WHERE id = %s".format(data['day'].lower())
            cursor.execute(sql, (data['value'], data['id']))
        timetable_db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/api/notes', methods=['GET'])
def get_notes():
    with timetable_db.cursor() as cursor:
        cursor.execute("SELECT notes FROM notes_table WHERE id = 1")
        result = cursor.fetchone()
    return jsonify({'notes': result['notes']})

@app.route('/api/save_notes', methods=['POST'])
def save_notes():
    try:
        data = request.json
        with timetable_db.cursor() as cursor:
            sql = "UPDATE notes_table SET notes = %s WHERE id = 1"
            cursor.execute(sql, (data['notes'],))
        timetable_db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)
