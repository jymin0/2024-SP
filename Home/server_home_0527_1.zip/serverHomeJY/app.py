from flask import Flask, render_template, request, redirect, url_for, session
import pymysql

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # 세션을 사용하려면 필요합니다.

# MySQL database connection using pymysql
db = pymysql.connect(
    host="localhost",
    user="root",
    password="root",
    database="member"
)

@app.before_request
def before_request():
    if 'email' in session:
        session['logged_in'] = True
    else:
        session['logged_in'] = False

@app.route('/')
def home():
    return redirect(url_for('index'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cursor = db.cursor(pymysql.cursors.DictCursor)
        query = "SELECT * FROM members WHERE email = %s AND password = %s"
        cursor.execute(query, (email, password))
        result = cursor.fetchone()
        cursor.close()

        if result:
            session['email'] = email  # 로그인 성공 시 세션에 이메일 저장
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cursor = db.cursor()
        query = "INSERT INTO members (email, password) VALUES (%s, %s)"
        cursor.execute(query, (email, password))
        db.commit()
        cursor.close()

        return redirect(url_for('login'))

    return render_template('signup.html')

@app.route('/index')
def index():
    return render_template('index.html', logged_in=session.get('logged_in', False))

@app.route('/timetable')
def timetable():
    return render_template('timetable.html', logged_in=session.get('logged_in', False))

@app.route('/cardnews')
def cardnews():
    return render_template('cardnews.html', logged_in=session.get('logged_in', False))

@app.route('/board')
def board():
    return render_template('board.html', logged_in=session.get('logged_in', False))

@app.route('/logout')
def logout():
    session.pop('email', None)  # 로그아웃 시 세션에서 이메일 제거
    session['logged_in'] = False
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
