CREATE DATABASE timetb;
USE timetb;